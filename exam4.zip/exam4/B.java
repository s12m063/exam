package egovframework.example.exam4;

import org.springframework.stereotype.Controller;

public class B {
/*	@Log4j2
//	@Controller
	public class DeptController {
//	        서비스 가져오기
	        private DeptService deptService; 
	...
	}*/
}
