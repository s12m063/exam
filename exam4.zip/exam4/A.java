package egovframework.example.exam4;

public class A {
//	M Model 데이터를 처리하는 부분(DB와 연동)
//	V View  화면을 보여주는 부분 (JSP,HTML등)
//	C Controller 사용자의 요청을 받아서 처리 흐름을 정리하는 부분
//	Controller가 사용자의 요청을 먼저 받아서 
//	어떤 데이터를 불러올지를 정하고
//	어떤 화면을 보여줄지를 결정한다
//	Model이 필요한 데이터를 만들거나 데이터베이스에서 값을 가져온다
//	View가 사용자가 실제로 보게될 화면이다
//	Controller가 요청을 받아서
//	Model을 통해 데이터를 준비하고
//	View를 통해 화면에 보여준다
}
