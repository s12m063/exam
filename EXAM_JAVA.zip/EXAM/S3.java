package EXAM;

import java.util.*;
import java.util.Random;
import java.util.Scanner;

public class S3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int d = input.nextInt();
		System.out.println("입력:" + d);
		Random rand = new Random();
		int[] num = new int[d];
		for (int i = 0; i < d; i++) {
			num[i] = rand.nextInt(100);
		}
		for (int n : num)
			System.out.print(n + " ");

		System.out.println();

		Arrays.sort(num);
		System.out.print("출력 ");
		for (int n : num)
			System.out.print(n + " ");
	}

}
