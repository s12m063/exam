package EXAM;

import java.util.Scanner;

public class S2 {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
		int a= input.nextInt();
		if(a>=19)System.out.println("성인");
		else {System.out.println("미성년자");
		 }
		}
	}
